/*
 * mitkAsToolInterface.h
 *
 *  Created on: 2018. dec. 29.
 *      Author: ervin
 */

#ifndef MITKASTOOLINTERFACE_H_
#define MITKASTOOLINTERFACE_H_

float* getSegSurfacePtr();

#endif /* MODULES_SEGMENTATION_ALGORITHMS_MITKASTOOLINTERFACE_H_ */
